﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CalculateHours;

namespace PROG6212_PART1
{
    public partial class MainWindow : Window
    {
        // ObservableCollection to store module information
        public static ObservableCollection<ModuleInfo> ModuleInfoCollection { get; set; } = new ObservableCollection<ModuleInfo>();

        public MainWindow()
        {
            InitializeComponent();
        }

        // Data class to represent module information
        public class ModuleInfo
        {
            public String? ModuleCode { get; set; }
            public String? ModuleName { get; set; }
            public int NumberOfCredits { get; set; }
            public int ClassHoursPerWeek { get; set; }
            public int SelfStudyHoursPerWeek { get; set; }
            public int RemainingHours { get; set; }
            public int NumberOfWeeksSemester { get; set; }
            public int HoursWorked { get; set; }
            public DateTime SemesterDate { get; set; }
            public DateTime EndDate { get; set; }
            public DateTime StudyDate { get; set; }
        }

        private void AddModule_Click(object sender, RoutedEventArgs e)
        {
            CalculateAndAddModule(); // Calling the method to calculate and add a module
        }

        private bool ValidateInput()
        {
            int numberOfCredits, classHoursPerWeek, numberOfWeeksSemester, numberOFHoursWorked;

            // Checking if input fields contain valid numeric values
            if (!int.TryParse(txtCredits.Text, out numberOfCredits) ||
                !int.TryParse(txtClassHours.Text, out classHoursPerWeek) ||
                !int.TryParse(txtWeeksInSemester.Text, out numberOfWeeksSemester) ||
                !int.TryParse(txtHoursWorked.Text, out numberOFHoursWorked))
            {
                MessageBox.Show("Invalid input. Please enter valid numeric values.");
                return false; // Input is not valid
            }

            return true; // Input is valid
        }

        // Method to calculate and add a module
        private void CalculateAndAddModule()
        {
            try
            {
                if (!ValidateInput())
                {
                    return; // Validation failed, do not proceed
                }

                string moduleCode = txtModuleCode.Text;
                string moduleName = txtModuleName.Text;
                int numberOfCredits, classHoursPerWeek, numberOfWeeksSemester, numberOFHoursWorked;

                // Parse the input values
                if (!int.TryParse(txtCredits.Text, out numberOfCredits) ||
                    !int.TryParse(txtClassHours.Text, out classHoursPerWeek) ||
                    !int.TryParse(txtWeeksInSemester.Text, out numberOfWeeksSemester) ||
                    !int.TryParse(txtHoursWorked.Text, out numberOFHoursWorked))
                {
                    MessageBox.Show("Invalid input. Please enter valid numeric values.");
                    return;
                }

                Class1 calculate = new Class1();
                calculate.setUserInput(numberOfCredits, numberOfWeeksSemester, classHoursPerWeek, numberOFHoursWorked);

                double selfStudyHours = calculate.CalculateSelfStudyHours();
                double remainingStudyHours = calculate.CalculateRemainingStudyHours(selfStudyHours);

                // Adding module information to the collection
                ModuleInfoCollection.Add(new ModuleInfo
                {
                    ModuleCode = moduleCode,
                    ModuleName = moduleName,
                    NumberOfCredits = numberOfCredits,
                    ClassHoursPerWeek = classHoursPerWeek,
                    NumberOfWeeksSemester = numberOfWeeksSemester,
                    SelfStudyHoursPerWeek = (int)selfStudyHours,
                    RemainingHours = (int)remainingStudyHours,
                    HoursWorked = numberOFHoursWorked,
                    SemesterDate = dpStartDate.SelectedDate.Value.Date,
                    EndDate = dpEndDate.SelectedDate.Value.Date,
                    StudyDate = dpStudyDate.SelectedDate.Value.Date,
                });

                // After successfully adding a module, clear input fields and update data grids
                ClearInputFields();
                UpdateDataGrids();

                MessageBox.Show("Module added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        // Method to clear input fields
        private void ClearInputFields()
        {
            txtModuleCode.Clear();
            txtModuleName.Clear();
            txtCredits.Clear();
            txtClassHours.Clear();
            txtWeeksInSemester.Clear();
            txtHoursWorked.Clear();

            // Clearing the input of the date picker
            dpStartDate.SelectedDate = null;
            dpEndDate.SelectedDate = null;
            dpStudyDate.SelectedDate = null;
        }

        // Method to update data grids
        private void UpdateDataGrids()
        {
            // Updating the ListView and other data grids logic here
            // Sortting ModuleInfoCollection alphabetically by the ModuleCode
            ModuleInfoCollection = new ObservableCollection<ModuleInfo>(ModuleInfoCollection.OrderBy(module => module.ModuleCode));

            // Setting the sorted collection as the DataContext for the ListView
            lvModules.ItemsSource = ModuleInfoCollection;
            lvSemesterInformation.ItemsSource = ModuleInfoCollection;
            lvRemainingHours.ItemsSource = ModuleInfoCollection;
        }

        private void lvModules_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataContext = ModuleInfoCollection;
        }

        private void lvSemesterInformation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataContext = ModuleInfoCollection;
        }

        private void lvRemainingHours_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataContext = ModuleInfoCollection;
        }

        // Event handler for the exit button
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            // Close the application
            Application.Current.Shutdown();
        }
    }

}

