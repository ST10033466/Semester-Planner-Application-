﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateHours
{
    public class Class1
    {
        public static int NumberOfCredits { get; set; }
        public static int NumberOfWeeksSemester { get; set; }
        public static int ClassHoursPerWeek { get; set; }
        public static int HoursWorked { get; set; }

        // Method to set user input values
        public void setUserInput(int numberOfCredits, int numberOfWeeksSemester, int classHoursPerWeek, int numberOFHoursWorked)
        {
            // Setting the input values in the class properties
            NumberOfCredits = numberOfCredits;
            NumberOfWeeksSemester = numberOfWeeksSemester;
            ClassHoursPerWeek = classHoursPerWeek;
            HoursWorked = numberOFHoursWorked;
        }

        // Method to calculate self-study hours per week
        public double CalculateSelfStudyHours()
        {
            // Ensurring that NumberOfWeeks is greater than ClassHoursPerWeek to avoid division by zero
            if (NumberOfWeeksSemester <= ClassHoursPerWeek)
            {
                throw new InvalidOperationException("NumberOfWeeks needs to be greater than ClassHoursPerWeek.");
            }

            //Calculations for the number of self study hours that is required 
            Double selfStudyHours = (NumberOfCredits * 10.0) / (NumberOfWeeksSemester - ClassHoursPerWeek);

            return selfStudyHours;
        }

        public double CalculateRemainingStudyHours(Double selfStudyHours) 
        {
            //Calculations for the number of self study hours that are remaining
            Double remainingStudyHours = selfStudyHours - HoursWorked;

            return remainingStudyHours;
        }
    }
}
